
Power BI Report Enhancement - Day 8 Tasks

1. Load the same data model from Day 7 ("Cement Company_Data Model.xlsx").

2. Page-1 Enhancements:
   - Change the Month axis to Calendar Year order (alphabetical).
   - Create 6 bookmarks (one for each Plant ID: 1 to 6).
   - Add 6 buttons labeled Plant 1 through Plant 6.
   - Buttons should switch views using bookmarks and show Production, Target, and Shipped Orders/Quantity by Year & Month.

3. Page Navigator:
   - Add a Page Navigator to allow navigation between pages (Page 1, Page 2, Page 3, Page 4).

4. Page-2 Enhancements:
   - Add a Table visual to show Month-wise Total Production in MT.
   - Apply Conditional Formatting:
     - If Production >= 80% of Target → Green background
     - If Production < 60% of Target → Red background
     - Else → Yellow background

5. Styling:
   - Apply a consistent Power BI Theme.
   - Ensure equal spacing between visuals and aligned margins for neat layout.

6. Buttons:
   - Group all Plant buttons.
   - After grouping, use Format tab options to customize appearance.

7. Email the final .pbix report to your mentor as per instructions.

Note: This ZIP includes only the data and guidelines. Use Power BI to implement the visuals and bookmarks.
