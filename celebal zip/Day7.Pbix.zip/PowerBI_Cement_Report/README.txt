
Power BI Report Setup Instructions for Cement Company Data Model

1. Load the Excel file "Cement Company_Data Model.xlsx" into Power BI.

2. Perform ETL:
   - Clean column names and remove unnecessary rows if any.
   - Transform dates and numeric columns properly.
   - Create relationships among tables as needed.

3. Visualizations:
   Page 1:
   - Add Pie, Bar, Column, and Line Chart.
   - Sort by Fiscal Year (configure Date table accordingly).
   - Add Slicer (e.g., Region, Date).
   - Sync slicer with Page 2.
   - Update visual interaction: Pie chart should NOT filter Bar chart.

   Page 2:
   - Add 2 custom visuals (e.g., Sankey, Waterfall, or any Marketplace visual).

   Page 3:
   - Forecast Production for next 6 months using Line chart.
   - Add Average dotted line using Analytics pane.

   Page 4:
   - Add Line chart for last 2 months of Shipped Quantity.
   - Add Firm Orders as Tooltip (using Tooltip measure or page).

4. Hierarchies:
   - State -> City
   - Year -> Month -> Date

5. Tooltip:
   - On hover over State/City, show tooltip with shipped quantity by Plants.

This ZIP includes the Excel data model. Please build the visuals and models in Power BI using the instructions above.
